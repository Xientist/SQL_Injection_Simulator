<?php

include 'register.html';

?>